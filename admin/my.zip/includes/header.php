<?php include "includes/db.php";?>
<?php include "includes/function.php";?>
<?php session_start();?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="/numsac/admin/css/bootstrap.css">
    <link rel="stylesheet" href="/numsac/admin/css/slick.css">
    <link rel="stylesheet" href="/numsac/admin/css/slick-theme.css">
    <link rel="stylesheet" type="text/css" href="/admin/css/style.css">

    <script src="js/jquery.js"></script>

    <title>Nasir Uddin Model School and College</title>
</head>
<body>