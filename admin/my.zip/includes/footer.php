<footer>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <p class="lead text-center text-muted footer_p mb-0">Copyright &copy; All right reserve by Naeem Hasan</p>
            </div>
        </div>
    </div>
</footer>



<script src="js/bootstrap.js"></script>
<script src="js/popper.js"></script>

<script type="text/javascript" src="/numsac/admin/js/main.js"></script>
</body>
</html>